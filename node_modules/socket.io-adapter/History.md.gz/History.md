
0.4.0 / 2015-12-03
==================

  * package: bump `debug`
  * use a `Room` class to efficiently track room size
  * allow `clients(fn)`
  * call the callback on `delAll`

0.3.1 / 2014-10-27
==================

 * bump parser version
 * fix room autopruning
 * add autoprunning of empty rooms
 * rooms are now created as objects
 * added the repository field.
 * updated the debug dependency.

0.3.0 / 2014-05-30
==================

 * bump `socket.io-parser` for binary ack fix

0.2.0 / 2014-03-14
==================

 * upgraded faster parser

0.1.0 / 2014-03-07
==================

 * initial commit
