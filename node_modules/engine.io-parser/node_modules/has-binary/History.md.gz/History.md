
0.1.6 / 2015-01-24
==================

 * fix "undefined function" bug when iterating
   an object created with Object.create(null) [gunta]

0.1.5 / 2014-09-04
==================

 * prevent browserify from bundling `Buffer`
