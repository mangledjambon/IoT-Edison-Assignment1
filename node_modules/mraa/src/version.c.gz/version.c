#include "version.h"

const char* gVERSION = "v0.10.1";
const char* gVERSION_SHORT = "0.10.1";
